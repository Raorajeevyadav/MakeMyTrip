package com.plateiq.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;

public class LoginPage {

WebDriver driver;
	
	public LoginPage(WebDriver driver) {
		 this.driver=driver;
		 }
	
	By loginbox = By.xpath("//li[@class='makeFlex hrtlCenter font10 makeRelative lhUser']");
	By username = By.xpath("//input[@id='username']");
	By password = By.xpath("//input[@id='password']");
	By loginbtn = By.xpath("//button[@class='capText font16']");
	
	
	 public void clickOnLogin() throws InterruptedException {
		 
	    	driver.findElement(loginbox).click();
			 
			 
		 }
	 public void enterUsername() throws InterruptedException {
		 
	    	driver.findElement(username).click();
	    	driver.findElement(username).sendKeys("testplateiq@gmail.com");
	    	Thread.sleep(1000);
	    	driver.findElement(username).sendKeys(Keys.ENTER);
			 
			 
		 }
	 public void enterPassword() throws InterruptedException {
		 
	    	driver.findElement(password).click();
	    	driver.findElement(password).sendKeys("test@123");
	    	Thread.sleep(1000);
	    	driver.findElement(password).sendKeys(Keys.ENTER);
			 
			 
		 }
	 public void clickOnBookNow() throws InterruptedException {
		 
	    	driver.findElement(loginbtn).click();
			 
			 
		 }
	
	
	
	
	
	
}
