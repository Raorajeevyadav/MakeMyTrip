package com.plateiq.pages;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class HomePage {
	
	WebDriver driver;
	
	public HomePage(WebDriver driver) {
		 this.driver=driver;
		 }
	
	By sFlight = By.xpath("//span [contains(@class, 'chNavText darkGreyText')][text()='Flights']");
	
	By source = By.xpath("//span[text()='From']");
	
	By dest = By.xpath("//input[@placeholder='To']");
	
//	By departure_date=By.xpath("");
	By return_date=By.xpath("//div[@data-cy='returnArea']");
	By traveller=By.xpath("//p[contains(text(),'Economy/Premium Economy')]");
	By search=By.xpath("//a[contains(text(),'Search')]");
	By booknow=By.xpath("//*[@class='splitFooterButton button buttonPrimary buttonBig ']");
	
	
	
	//Method to click on Flight Link 
	 public void clickOnFlight() {
	 driver.findElement(sFlight).click();}
	 
	 
	 public void selectSource() throws InterruptedException {
		 
		driver.findElement(source).click();
			
			
			WebElement searchBox=driver.findElement(By.xpath("//input[@placeholder='From']"));
			
			searchBox.sendKeys("Goa");
			Thread.sleep(3000);
			String text;
			//This method find the exact Text in Autocomplete dropdown suggestion
			do {

				//this will select the first option
				searchBox.sendKeys(Keys.ARROW_DOWN);

				//this will get the value of first option
				text = searchBox.getAttribute("value");
				System.out.println(text);

				//this will compare the text we want in suggestion box
				if (text.equals("Goa")) {
					searchBox.sendKeys(Keys.ENTER);
					break;
				}
				Thread.sleep(3000);
			} while (!text.isEmpty());}
	 
	 public void selectDest() throws InterruptedException {
		 
			driver.findElement(dest).click();
			String text;	
			WebElement dest=driver.findElement(By.xpath("//input[@placeholder='To']"));
			
			dest.sendKeys("Mumbai");
			Thread.sleep(2000);
			
				//This method find the exact Text in Autocomplete dropdown suggestion
			do {

				//this will select the first option
				dest.sendKeys(Keys.ARROW_DOWN);

				//this will get the value of first option
				text = dest.getAttribute("value");
				System.out.println(text);

				//this will compare the text we want in suggestion box
				if (text.equals("Mumbai")) {
					dest.sendKeys(Keys.ENTER);
					break;
				}
				Thread.sleep(3000);
			} while (!text.isEmpty());
			
	 }
			
	 public void selectDepartureDate() throws InterruptedException {
		 
		 
		 
		    LocalDate date = LocalDate.now();
		    LocalDate After2day = date.plusDays(2);
		    System.out.println("Today date : " +   date);
	
		   
		    SimpleDateFormat dateFormat = new SimpleDateFormat("E MMM dd yyyy");   
		    
		    Date date1 = Date.from(After2day.atStartOfDay(ZoneId.systemDefault()).toInstant());
		  
		    String travel_date= dateFormat.format(date1);
		    
		    System.out.println("Travel date: "+travel_date);
		    
		 
		//div[@aria-label='Thu Jun 03 2021']
		 driver.findElement(By.xpath("//div[@aria-label='"+travel_date+"']")).click();
		 
		 
		 
		 
	 }
	 
	 public void selectReturnDate() throws InterruptedException {
		 
		 
		 driver.findElement(return_date).click();
		    LocalDate date = LocalDate.now();
		    LocalDate After3day = date.plusDays(3);
		    System.out.println("Today date : " +   date);
	
		   
		    SimpleDateFormat dateFormat = new SimpleDateFormat("E MMM dd yyyy");   
		    
		    Date date1 = Date.from(After3day.atStartOfDay(ZoneId.systemDefault()).toInstant());
		  
		    String return_date= dateFormat.format(date1);
		    
		    System.out.println("Return date: "+return_date);
		    
		 driver.findElement(By.xpath("//div[@aria-label='"+return_date+"']")).click();
		 
		 
		 
		 
	 }
	 public void selectTravellClasse() throws InterruptedException {
		 
		 driver.findElement(traveller).click();
		 driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div/div[1]/div[2]/div[1]/div[5]/div[2]/div[1]/div/div[1]/ul/li[2]")).click();
			//Click on Apply 
			driver.findElement(By.xpath("//button[contains(text(),'APPLY')]")).click();
		 
		 
		 
		 
		 
	 }
    public void clickOnSearch() throws InterruptedException {
		 
    	driver.findElement(search).click();
		 
		 
	 }
    public void clickOnBookNow() throws InterruptedException {
		 
    	driver.findElement(booknow).click();
		 
		 
	 }
			
			
}
		 
		 
		 
		 
		 
		 
		 
		 
	 
	 
	 
	 
	 
	 
	
	


