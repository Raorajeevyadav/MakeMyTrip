package com.plateiq.testcase;

import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.plateiq.pages.HomePage;
import com.plateiq.pages.LoginPage;



public class Assignment1 {

	WebDriver driver;

	@BeforeMethod

	public void setup() {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\BA49050\\eclipse-workspace\\PlateIQ\\Driver\\chromedriver.exe");
		driver = new ChromeDriver();
		System.out.println("Launch the Browser");
		driver.get("https://www.makemytrip.com/");
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.manage().timeouts().pageLoadTimeout(25, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		try {

			driver.findElement(By.xpath("//div[@class='autopop__wrap makeFlex column defaultCursor']")).isDisplayed();
			System.out.println("Pop up is showing");
			driver.findElement(By.xpath("//li[@class='makeFlex hrtlCenter font10 makeRelative lhUser']")).click();

		}

		catch (Exception e) {

		}
	}

	@Test

	public void testCase1() throws InterruptedException {

		HomePage home = new HomePage(driver);
		LoginPage lp = new LoginPage(driver);
		// this.driver=driver;
		System.out.println("Test Case 1 execution start");

		
		// Click on Flight
		home.clickOnFlight();
		System.out.println("Click on Flight");

		// Select the Source as Goa
		home.selectSource();
		
		// Select the Destination as Mumbai
		home.selectDest();
		
		

		// Select the Departure date 2 days from Today
		home.selectDepartureDate();

		// Select the Return date 3 days from Today
		home.selectReturnDate();

		// Select travell class as economy with 1 adult and 1 child
		home.selectTravellClasse();

		// Click on Search Button
		home.clickOnSearch();

		// Click on Book Now Button
		home.clickOnBookNow();

	}

	@Test

	public void testCase2() throws InterruptedException {

		LoginPage login = new LoginPage(driver);
		login.clickOnLogin();
		login.enterUsername();
		login.enterPassword();
		login.clickOnBookNow();

	}

	@AfterMethod

	public void teardown() {

		driver.close();
	}

}
